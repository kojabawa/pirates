import dash
import dash_table
import dash_core_components as dcc
import dash_html_components as html
import dash_bootstrap_components as dbc
from dash.dependencies import Input, Output
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime as dt
from textblob import TextBlob
import seaborn as sns
import os

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
from wordcloud import WordCloud, ImageColorGenerator


#
#Importação e tratamento de bases
#
news = pd.read_excel('bases/market_analysis_news.xlsx')
news['TBPolarity'] = pd.Series(dtype='float')
news['TBSubjectivity'] = pd.Series(dtype='float')
news_pickle = news

def textblob_pol(body):
    return TextBlob(body).sentiment.polarity                         #aplicando o processo feito com os comentários do reddit
def textblob_sub(body):    
    return TextBlob(body).sentiment.subjectivity

news_pickle['TBPolarity'] = news_pickle['Content'].apply(textblob_pol)
news_pickle['TBSubjectivity'] = news_pickle['Content'].apply(textblob_sub)
news_pickle.to_pickle('bases/noticias.pkl')

coins = pd.DataFrame()
for coin in ['btcusd']:
        coin = pd.read_csv('bases/{}.csv'.format(coin),sep=',',header=1,usecols=['Date','Symbol','Close','Open','High','Low'])
        coin['Date'] = pd.to_datetime(coin['Date'],format='%Y-%m-%d')
        coin['Price MA(16)'] = coin['Close'].rolling(16).mean()        
        
        coins = pd.concat([coin,coins],axis=0,ignore_index=True)
#
#Códigos auxiliares do Dash
#

options_choose_vars = [{'label':i,'value':i} for i in [x for x in coins.columns if x not in ['Date','Symbol']]]
options_choose_coins = [{'label':i,'value':i} for i in [x for x in list(set(coins['Symbol']))]]

def busca(df, *words):
    return df[np.logical_xor.reduce([df['Content'].str.contains(word) for word in words])]

news_pickle = pd.read_pickle('bases/noticias.pkl')
news_pickle['ContentFull'] = news_pickle['Content'].str.encode('utf-8').str.decode('ascii',errors='ignore')
news_pickle['Content'] = [x[:1900]+'...' if len(x)>1000 else x[:1000] for x in news_pickle['ContentFull']]
news_pickle['TitleFull'] = news_pickle['Title']
news_pickle['Title'] = news_pickle['TitleFull']
news_pickle['Date_datetime'] = pd.to_datetime(news_pickle['Date'],format='%Y-%m-%d')
news_pickle['Date'] = news_pickle['Date_datetime'].astype(str)
news_pickle = busca(news_pickle, 'bitcoin', 'Bitcoin')
news_pickle['weight'] = news_pickle['Views']/news_pickle.groupby('Date')['Views'].transform('sum')
news_pickle['value']=news_pickle['TBPolarity']*news_pickle['weight']

def newscorr(dado1, dado2):                                          #função que avalia o melhor número de dias de lag
    dummy=0                                                         #através da correlação entre os dados extraídos e os dados do btc
    max = 0                                                         #dado 1 começa a partir da i+1-ésima, logo é o dado que queremos prever
    for i in range(15):
        if i == 7:
            print("Lag de maior correlação:", max, " dias atrás")
            return 
        k=i+1
        h=i-7
        if i==0:
            print("Correlação com notícias do dia anterior:", np.corrcoef(dado1[k:h].astype('float64'), dado2[:-8].astype('float64'))[0][1])
        else:
            print("Correlação com notícias de ", 1+i, " dias atrás:", np.corrcoef(dado1[k:h].astype('float64'), dado2[:-8].astype('float64'))[0][1])
        if np.corrcoef(dado1[k:h].astype('float64'), dado2[:-8].astype('float64'))[0][1]>dummy:
            dummy = np.corrcoef(dado1[k:h].astype('float64'), dado2[:-8].astype('float64'))[0][1]
            max=i+1

newsagg = news_pickle.set_index('Date_datetime').groupby(pd.Grouper(freq='D')).sum()

idx = pd.date_range('01-01-2019', '08-17-2020')
newsagg = newsagg.reindex(idx, fill_value=0)
newsagg.reset_index(inplace=True)
newsagg['valor']=0

for i in range(np.shape(newsagg)[0]):
    if i == 12:
        newsagg.loc[i, 'valor'] = newsagg.loc[i, 'value']
    if i == 13:
        newsagg.loc[i, 'valor'] = newsagg.loc[i-1, 'value']/2
    elif i>13:
        newsagg.loc[i, 'valor'] = newsagg.loc[i, 'value'] + newsagg.loc[i-1, 'value']/2 + \
        newsagg.loc[i-2, 'value']/6 + newsagg.loc[i-3, 'value']/8 +newsagg.loc[i-4, 'value']/10 + \
        newsagg.loc[i-5, 'value']/12 + newsagg.loc[i-6, 'value']/14 + newsagg.loc[i-7, 'value']/16 + \
        newsagg.loc[i-8, 'value']/18 + newsagg.loc[i-9, 'value']/20 + newsagg.loc[i-10, 'value']/22 + \
        newsagg.loc[i-11, 'value']/24 + newsagg.loc[i-12, 'value']/26 + newsagg.loc[i-13, 'value']/28

newsagg.loc[newsagg["valor"] != 0].mean()
newsagg.loc[newsagg["valor"] == 0, 'valor'] = 0.088258
corr = pd.merge(left=coins, left_on='Date',
         right=newsagg, right_on='index')
corr = corr.round(4)

medias = pd.DataFrame()
medias['MA16']= corr['Close'].rolling(window=16).mean().dropna()
medias['MA1'] = corr.loc[15:, 'Close'].rolling(window=1).mean().dropna()

medias = medias.set_index(corr.loc[15:, 'index'])
medias['posição']  = medias['MA1'] > medias['MA16']
medias['anterior'] =  medias['posição'].shift(1)
medias.dropna(inplace=True)
medias['mudança'] = np.where(medias['posição'] == medias['anterior'], False, True)
medias = medias.reset_index()
medias['venda']  = np.where((medias['posição'] == False) & (medias['mudança'] == True), True, False)
medias['compra'] = np.where((medias['posição'] == True) & (medias['mudança'] == True), True, False)

def lucro_noticias_arrojado(precos, decisao,start_date,end):

    start_date = pd.to_datetime(pd.Series([dt.strptime(start_date[:10],'%Y-%m-%d')])).iloc[0]
    end = pd.to_datetime(pd.Series([dt.strptime(end[:10],'%Y-%m-%d')])).iloc[0]
    
    precos = precos[(precos['Date']>=start_date)&(precos['Date']<=end)].reset_index(drop=True)
    decisao = decisao[(decisao['index']>=start_date)&(decisao['index']<=end)].reset_index(drop=True)
    
    inicio = True
    btc = 0
    primeiro = False
    caixa = 0
    investimento = 0
    valor = []
    dummy = 0
    start = 0
    
    for i in range(len(precos)):
        if (inicio == True) & (decisao.loc[i, 'compra'] == True):
            inicio = False
            btc = 1
            primeiro = True
            start = i
            investimento = precos.loc[i+1, 'Open']
        elif (inicio == False) & (decisao.loc[i, 'compra'] == True) & (primeiro == False):
            buyprice = precos.loc[i+1, 'Open']
            btc = btc + caixa / precos.loc[i+1, 'Open']
            caixa = max(caixa - btc * precos.loc[i+1, 'Open'], 0)
        elif (inicio == False) & (decisao.loc[i, 'venda'] == True) & (primeiro == True):
            btc = 0
            primeiro = False
            caixa = precos.loc[i+1, 'Close']
        elif (inicio == False) & (decisao.loc[i, 'venda'] == True) & (primeiro == False):
            vendendo = min(1, np.log((precos.loc[i+1, 'valor']**2)/precos.loc[0:i+1, 'valor'].std())/10)
            caixa = caixa + btc * precos.loc[i+1, 'Close'] * vendendo
            btc = btc * (1 - vendendo)
        valor.append(caixa + btc*precos.loc[i, 'Close'])
    
    ######################################################################################################
    #### results #########################################################################################
    ######################################################################################################

    precos['posicao'] = valor
    valores_df = precos[['index','posicao','Close']]
    valores_df.columns = ['index','posicao','BTCusd']
    df_medias = valores_df.melt('index', var_name='ativo', value_name='usd')
    df_medias_cv = pd.merge(decisao[['index','venda','compra']],
                            df_medias, how='left', on='index')

    retorno_modelo  = 100*list(filter(None, valor))[-1]/investimento-100
    retorno_mercado = 100*list(filter(None, precos['Close']))[-1]/investimento-100
    retorno_perc    = (retorno_modelo/retorno_mercado - 1) *100

    def sharpe_ratio(df_preco):
        sharpe_ratio = df_preco.pct_change()
        sharpe_ratio = sharpe_ratio.diff()
        sharpe_ratio = sharpe_ratio.mean()/sharpe_ratio.std() * np.sqrt(365)
        return sharpe_ratio
    
    sharpe_modelo = sharpe_ratio(valores_df['posicao'][start:])
    sharpe_mercado= sharpe_ratio(precos['Close'][start:])

    return df_medias_cv,retorno_modelo,retorno_mercado,retorno_perc,valores_df['posicao'][start:].std(),precos['Close'][start:].std(),sharpe_modelo,sharpe_mercado

#
#Dashboard
#
app = dash.Dash(__name__)

app.layout = html.Div([
    dcc.Location(id='url', refresh=False),
    html.Div(id='page-content')
])

tendencia_page = html.Div([

    html.Div([
        html.H2("Cryptodash"),
        dcc.Link('Análise de Tendência',href='/tendencia',style={'font-family':"DejaVu,Sans Mono, monospace",'margin-left':'7.5em','font-size':'25px','color':'#ffffff',"text-decoration": "none"}),
        dcc.Link('Análise de Notícias',href='/noticias',style={'font-family':"DejaVu,Sans Mono, monospace",'margin-left':'7.0em','font-size':'25px','color':'#ffffff',"text-decoration": "none"}), #Couldn't make links work in CSS (maybe has to do w/ dcc, not html)
        html.Img(src="/assets/coin.png")
    ],className='banner'),

    html.Div([

        html.Div([
                html.H1(['Criptomoeda'],className='three columns',style={'font-family':"DejaVu,Sans Mono, monospace",'marginLeft':'55px','fontSize':20}),
                html.H1(['Variáveis'],className='three columns',style={'font-family':"DejaVu,Sans Mono, monospace",'marginLeft':'15px','fontSize':20}),
                html.H1(['Intervalo de Data'],className='four columns',style={'font-family':"DejaVu,Sans Mono, monospace",'marginLeft':'230px','fontSize':20})
        ],className='twelve columns'),
        
        html.Div([
             dcc.Dropdown(id='choose_coins',value='BTCUSD',options = options_choose_coins,multi=False,style={'marginTop':'7px','marginLeft':'20px'}),
        ],className='three columns'),

        html.Div([
            dcc.Dropdown(id='choose_vars',value=['Close'],options = options_choose_vars,multi=True,style={'marginTop':'7px','marginLeft':'25px'})
        ],className='five columns'),

        html.Div([
                dcc.DatePickerRange(
                   id='date_interval',
                   min_date_allowed=dt(2019, 1, 1),
                   max_date_allowed=dt(dt.today().year, dt.today().month, dt.today().day),
                   start_date=dt(2019, 1, 1),
                   end_date=dt(dt.today().year, dt.today().month, dt.today().day),
                   style={'margin-left':'40px'},
                   clearable=True)
        ],className='four columns'),

    ],className='twelve columns'),
    
    html.Div([
        dcc.Graph(id='lineplot')
    ],className='nine columns'),


    html.Div([
            html.Div([
                dcc.Dropdown(id='valor',style={'marginTop':'30px','marginBottom':'5px'})
            ]),
            html.Div([
                dash_table.DataTable(id='table-carteira')
            ])
    ],className='three columns',style={'marginTop':'50px'}),
])


#Graph callback
@app.callback(
    Output('lineplot','figure'),
    [Input('date_interval','start_date'),Input('date_interval','end_date'),Input('choose_vars','value'),Input('choose_coins','value')]
)

def update_lineplot(start,end,var,coin):
        if type(var) != list:
                var = [var]
        if type(coin) != list:
                coin = [coin]

        coins_filtered = coins[(coins['Date']>=start)&(coins['Date']<=end)&(coins['Symbol'].isin(coin))]
        df = lucro_noticias_arrojado(corr[16:],medias,start,end)[0]
        df = df[(df['index']>=start)&(df['index']<=end)]
        print(medias)
        print(medias.columns)

        var = ['MA16','MA1']
        fig = go.Figure()
        for v in var:
                fig.add_trace(go.Scatter(x=medias['index'],y=medias[v],name=v,mode='lines',marker_color=px.colors.sequential.Viridis[var.index(v)]))
                if v == 'Close' or v == 'Open':
                        fig.add_trace(go.Scatter(x=coins_filtered['Date'],y=coins_filtered['High'],mode='lines',name='High',marker_color='#d9ccdc',showlegend=False))
                        fig.add_trace(go.Scatter(x=coins_filtered['Date'],y=coins_filtered['Low'],fill='tonexty',name='Low',mode='lines',showlegend=False,marker_color='#d9ccdc'))
        
        fig.add_trace(go.Scatter(x=df[df['ativo']=='posicao']['index'],y=df[df['ativo']=='posicao']['usd'],mode='lines',name='Posição',marker_color='#404040'))
        fig.add_trace(go.Scatter(x=df.loc[(df['compra'] == True) & (df['ativo'] == 'BTCusd'),
                        'index'],
                        y=df.loc[(df['compra'] == True) & (df['ativo'] == 'BTCusd'), 
                       'usd'],
                        mode='markers',
                        marker_size=8,
                        marker_color='green',
                        marker_symbol='triangle-up',
                        name='Compra'))
        fig.add_trace(go.Scatter(x=df.loc[(df['venda'] == True) & (df['ativo'] == 'BTCusd'),
                        'index'],
                        y=df.loc[(df['venda'] == True) & (df['ativo'] == 'BTCusd'), 
                       'usd'],
                        mode='markers',
                        marker_size=8,
                        marker_color='red',
                        marker_symbol='triangle-down',
                        name='Venda'))
        return fig

@app.callback(
        [Output('table-carteira','data'),Output('table-carteira','columns')],
        [Input('date_interval','start_date'),Input('date_interval','end_date')]
)

def update_table(start,end):
        medias_filtered = medias[(medias['index']>=start)&(medias['index']<=end)]
        corr_filtered = corr[(corr['index']>=start)&(corr['index']<=end)]

        resultados = lucro_noticias_arrojado(corr[16:],medias,start,end)
        df = resultados[0]
        
        df_resultados = pd.DataFrame()
        df_resultados['Variáveis'] = ['Retorno do Modelo','Retorno do Mercado','Ganho (%)','Std do Modelo','Std do Mercado','Sharpe do Modelo','Sharpe do Mercado']
        df_resultados['Valor'] = ['{:.2f}'.format(x) for x in [resultados[1],resultados[2],resultados[3],resultados[4],resultados[5],resultados[6],resultados[7]]]
        
        columns=[{'id':'Variáveis','name':'Variáveis'},{'id':'Valor','name':'Valor'}]
        
        return df_resultados.to_dict('records'),columns
        
noticia_page = html.Div([

    html.Div([
        html.H2("Cryptodash"),
        dcc.Link('Análise de Tendência',href='/tendencia',style={'font-family':"DejaVu,Sans Mono, monospace",'margin-left':'7.5em','font-size':'25px','color':'#ffffff',"text-decoration": "none"}),
        dcc.Link('Análise de Notícias',href='/noticias',style={'font-family':"DejaVu,Sans Mono, monospace",'margin-left':'7.0em','font-size':'25px','color':'#ffffff',"text-decoration": "none"}), #Couldn't make links work in CSS (maybe has to do w/ dcc, not html)
        html.Img(src="/assets/coin.png")
    ],className='banner'),

    html.Div([

        html.Div([
                html.H1(['Intervalo de Data'],className='four columns',style={'font-family':"DejaVu,Sans Mono, monospace",'marginLeft':'55px','fontSize':20})
        ],className='twelve columns'),
        
        html.Div([
                dcc.DatePickerRange(
                   id='date_interval',
                   min_date_allowed=dt(2019, 1, 1),
                   max_date_allowed=dt(dt.today().year, dt.today().month, dt.today().day),
                   start_date=dt(2019, 1, 1),
                   end_date=dt(dt.today().year, dt.today().month, dt.today().day),
                   style={'margin-left':'20px'},
                   clearable=True)
        ],className='four columns'),

    ],className='twelve columns'),
    
    html.Div([
            html.Div([    
                    html.Div([
                        dash_table.DataTable(
                        id='news_table',
                        style_as_list_view=True,
                        style_header={
                        'backgroundColor': 'rgb(230, 230, 230)',
                        'fontWeight': 'bold'
                        },
                        style_cell={'textAlign':'left','fontSize':12,'whiteSpace':'normal','height':'auto'},
                        page_size=1,
                        page_current=0,
                        page_action='custom')
                    ],className='eleven columns',style={'marginLeft':'20px','marginTop':'50px'}),
                    
                    html.Div([
                          html.A(href='',id='fonte_noticia', target='_blank',
                                 style={'font-family':"DejaVu,Sans Mono, monospace",'fontSize':11,'marginLeft':'20px'})
                    ],className='twelve columns')
             ],className='six columns'),
            
            html.Div([
                html.Img(id='wordcloud',style={'marginRight':'1000px'})
            ],className='three columns')
    ],className='twelve columns')
])


@app.callback(
        [Output('news_table','data'),Output('news_table','columns')],
        [Input('news_table', "page_current"),Input('news_table', "page_size"),
         Input('date_interval','start_date'),Input('date_interval','end_date')]
)

def update_table(page_current,page_size,start,end):
        news_filtered = news_pickle[(news_pickle['Date_datetime']>start)&(news_pickle['Date_datetime']<=end)][['Date','Content','Title']].reset_index(drop=True)
        news_filtered_paged = news_filtered.iloc[page_current*page_size:(page_current+1)*page_size]
        news_filtered_paged.columns = ['Date',news_filtered_paged.Date.iloc[0]+': '+news_filtered_paged.Title.iloc[0],'Title']
        print(news_filtered_paged)
        columns=([{'id': news_filtered_paged.Date.iloc[0]+': '+news_filtered_paged.Title.iloc[0],'name':news_filtered_paged.Date.iloc[0]+': '+news_filtered_paged.Title.iloc[0]}])
        return news_filtered_paged.to_dict('records'),columns

@app.callback(
        [Output('fonte_noticia','href'),Output('fonte_noticia','children')],
        [Input('news_table', "page_current"),Input('news_table', "page_size"),
         Input('date_interval','start_date'),Input('date_interval','end_date')]
)

def update_link(page_current,page_size,start,end):
        news_filtered = news_pickle[(news_pickle['Date_datetime']>start)&(news_pickle['Date_datetime']<=end)][['Date','Content','Link']].reset_index(drop=True)
        news_filtered_paged = news_filtered.iloc[page_current*page_size:(page_current+1)*page_size]
        return [news_filtered_paged.Link.iloc[0]],['Fonte: '+news_filtered_paged.Link.iloc[0]]

@app.callback(
        Output('wordcloud','src'),
        [Input('news_table', "page_current"),Input('news_table', "page_size"),
         Input('date_interval','start_date'),Input('date_interval','end_date')]
)

def update_wordcloud(page_current,page_size,start,end):
        news_filtered = news_pickle[(news_pickle['Date_datetime']>start)&(news_pickle['Date_datetime']<=end)][['Date','ContentFull']].reset_index(drop=True)
        news_filtered_paged = news_filtered.iloc[page_current*page_size:(page_current+1)*page_size]

        text = news_filtered_paged['ContentFull'].iloc[0]

        ### Stopwords
        STOPWORDS = ["a","about",'tradingview','source',"above","after","again","against","ain","all","am","an","and","any","are","aren","aren't","as","at","be","because","been","before","being","below","between","both","but","by","can","couldn","couldn't","d","did","didn","didn't","do","does","doesn","doesn't","doing","don","don't","down","during","each","few","for","from","further","had","hadn","hadn't","has","hasn","hasn't","have","haven","haven't","having","he","her","here","hers","herself","him","himself","his","how","i","if","in","into","is","isn","isn't","it","it's","its","itself","just","ll","m","ma","me","mightn","mightn't","more","most","mustn","mustn't","my","myself","needn","needn't","no","nor","not","now","o","of","off","on","once","only","or","other","our","ours","ourselves","out","over","own","re","s","same","shan","shan't","she","she's","should","should've","shouldn","shouldn't","so","some","such","t","than","that","that'll","the","their","theirs","them","themselves","then","there","these","they","this","those","through","to","too","under","until","up","ve","very","was","wasn","wasn't","we","were","weren","weren't","what","when","where","which","while","who","whom","why","will","with","won","won't","wouldn","wouldn't","y","you","you'd","you'll","you're","you've","your","yours","yourself","yourselves","could","he'd","he'll","he's","here's","how's","i'd","i'll","i'm","i've","let's","ought","she'd","she'll","that's","there's","they'd","they'll","they're","they've","we'd","we'll","we're","we've","what's","when's","where's","who's","why's","would","able","abst","accordance","according","accordingly","across","act","actually","added","adj","affected","affecting","affects","afterwards","ah","almost","alone","along","already","also","although","always","among","amongst","announce","another","anybody","anyhow","anymore","anyone","anything","anyway","anyways","anywhere","apparently","approximately","arent","arise","around","aside","ask","asking","auth","available","away","awfully","b","back","became","become","becomes","becoming","beforehand","begin","beginning","beginnings","begins","behind","believe","beside","besides","beyond","biol","brief","briefly","c","ca","came","cannot","can't","cause","causes","certain","certainly","co","com","come","comes","contain","containing","contains","couldnt","date","different","done","downwards","due","e","ed","edu","effect","eg","eight","eighty","either","else","elsewhere","end","ending","enough","especially","et","etc","even","ever","every","everybody","everyone","everything","everywhere","ex","except","f","far","ff","fifth","first","five","fix","followed","following","follows","former","formerly","forth","found","four","furthermore","g","gave","get","gets","getting","give","given","gives","giving","go","goes","gone","got","gotten","h","happens","hardly","hed","hence","hereafter","hereby","herein","heres","hereupon","hes","hi","hid","hither","home","howbeit","however","hundred","id","ie","im","immediate","immediately","importance","important","inc","indeed","index","information","instead","invention","inward","itd","it'll","j","k","keep","keeps","kept","kg","km","know","known","knows","l","largely","last","lately","later","latter","latterly","least","less","lest","let","lets","like","liked","likely","line","little","'ll","look","looking","looks","ltd","made","mainly","make","makes","many","may","maybe","mean","means","meantime","meanwhile","merely","mg","might","million","miss","ml","moreover","mostly","mr","mrs","much","mug","must","n","na","name","namely","nay","nd","near","nearly","necessarily","necessary","need","needs","neither","never","nevertheless","new","next","nine","ninety","nobody","non","none","nonetheless","noone","normally","nos","noted","nothing","nowhere","obtain","obtained","obviously","often","oh","ok","okay","old","omitted","one","ones","onto","ord","others","otherwise","outside","overall","owing","p","page","pages","part","particular","particularly","past","per","perhaps","placed","please","plus","poorly","possible","possibly","potentially","pp","predominantly","present","previously","primarily","probably","promptly","proud","provides","put","q","que","quickly","quite","qv","r","ran","rather","rd","readily","really","recent","recently","ref","refs","regarding","regardless","regards","related","relatively","research","respectively","resulted","resulting","results","right","run","said","saw","say","saying","says","sec","section","see","seeing","seem","seemed","seeming","seems","seen","self","selves","sent","seven","several","shall","shed","shes","show","showed","shown","showns","shows","significant","significantly","similar","similarly","since","six","slightly","somebody","somehow","someone","somethan","something","sometime","sometimes","somewhat","somewhere","soon","sorry","specifically","specified","specify","specifying","still","stop","strongly","sub","substantially","successfully","sufficiently","suggest","sup","sure","take","taken","taking","tell","tends","th","thank","thanks","thanx","thats","that've","thence","thereafter","thereby","thered","therefore","therein","there'll","thereof","therere","theres","thereto","thereupon","there've","theyd","theyre","think","thou","though","thoughh","thousand","throug","throughout","thru","thus","til","tip","together","took","toward","towards","tried","tries","truly","try","trying","ts","twice","two","u","un","unfortunately","unless","unlike","unlikely","unto","upon","ups","us","use","used","useful","usefully","usefulness","uses","using","usually","v","value","various","'ve","via","viz","vol","vols","vs","w","want","wants","wasnt","way","wed","welcome","went","werent","whatever","what'll","whats","whence","whenever","whereafter","whereas","whereby","wherein","wheres","whereupon","wherever","whether","whim","whither","whod","whoever","whole","who'll","whomever","whos","whose","widely","willing","wish","within","without","wont","words","world","wouldnt","www","x","yes","yet","youd","youre","z","zero","a's","ain't","allow","allows","apart","appear","appreciate","appropriate","associated","best","better","c'mon","c's","cant","changes","clearly","concerning","consequently","consider","considering","corresponding","course","currently","definitely","described","despite","entirely","exactly","example","going","greetings","hello","help","hopefully","ignored","inasmuch","indicate","indicated","indicates","inner","insofar","it'd","keep","keeps","novel","presumably","reasonably","second","secondly","sensible","serious","seriously","sure","t's","third","thorough","thoroughly","three","well","wonder"]

        wordcloud = WordCloud(max_words=100,background_color="white",width=350,height=300).generate(text)
        plt.imshow(wordcloud, interpolation='bilinear')
        plt.title(loc='left',label='Wordcloud das Notícias',pad=5,fontdict={'fontname':'DejaVu','fontsize':15})
        plt.xticks([],[])
        plt.yticks([],[])

        plt.savefig('assets\wordcloud{}{}_{}{}.jpg'.format(start[6:8],start[9:11],end[6:8],end[9:11]))
        return 'assets\wordcloud{}{}_{}{}.jpg'.format(start[6:8],start[9:11],end[6:8],end[9:11])


#Page Callback (LAST CALLBACK)
@app.callback(
    Output('page-content','children'),
    [Input('url','pathname')]
)

def display_page(pathname):
    if pathname == '/tendencia':
        return tendencia_page
    elif pathname == '/noticias':
        return noticia_page
    else:
        return tendencia_page

#Rodar servidor local com a pagina
if __name__=='__main__':
    app.run_server()
