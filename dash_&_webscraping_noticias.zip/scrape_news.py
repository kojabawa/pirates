from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import pyautogui as pag
import pandas as pd
import time

driver = webdriver.Chrome('scrape_aux/chromedriver.exe')
driver.implicitly_wait(5)

#Já coletado
df_ja_coletado = pd.read_excel('bases/market_analysis_news.xlsx')
dates_ja_coletadas = list(df_ja_coletado['Date'].astype(str))

#
driver.get('https://cointelegraph.com/category/market-analysis')

links = []
dates = []
titles = []
contents = []
views = []

noticias = driver.find_elements_by_class_name('post-card-inline__title-link')

count = 0
while True:
    for noticia in noticias[count:]:
        
        date = driver.find_elements_by_class_name('post-card-inline__date')[count]
        date_str = date.get_attribute('datetime')
        
        views_news = driver.find_elements_by_class_name('post-card-inline__stats-item')[count]
        views_str = views_news.text

        count += 1
        if dates.count(date_str) == 2 or date_str in dates_ja_coletadas:
            df.to_excel('market_analysis_news(so_novas).xlsx')
            driver.close()
            exit()
        
        link = noticia.get_attribute('href')

        #Abre uma aba nova
        driver.find_element_by_tag_name('body').send_keys(Keys.CONTROL + 't')
        
        driver_noticia = webdriver.Chrome('scrape_aux/chromedriver.exe')
        driver_noticia.implicitly_wait(5)
        driver_noticia.get(link)
        
        title = driver_noticia.find_element_by_class_name('post__title')
        title_name = title.text
        time.sleep(2)

        content = driver_noticia.find_element_by_class_name('post-content')
        content_text = ''.join([paragraph.text.replace('“','').replace('”','') for paragraph in content.find_elements_by_tag_name('p')])

        print('{}:{}'.format(title_name,date_str))
        print(content_text[:50]+'...')
        print('Visualizações: ' + views_str)
        print()

        links.append(link)
        titles.append(title_name)
        dates.append(date_str)
        contents.append(content_text)
        views.append(views_str)

        df = pd.DataFrame()
        df['Link'] = links
        df['Date'] = dates
        df['Title'] = titles
        df['Content'] = contents
        df['Visualizações'] = views

        driver_noticia.close()
        time.sleep(0.8)
        pag.hotkey('alt','f4')
        time.sleep(0.8)

    pag.scroll(-1000000)
    pag.scroll(+700)
    pag.moveTo(366,329)
    pag.click()
    time.sleep(2)
    
    noticias = driver.find_elements_by_class_name('post-card-inline__title-link')

df = pd.concat([df,df_ja_coletado],ignore_index=True)
df.to_csv('market_analysis_news3.csv')



